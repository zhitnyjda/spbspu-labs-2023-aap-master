#include <iostream>
#include "helpersFunc.h"

int main()
{
	helperFunc helperFunc_;

	helperFunc_(&std::cin);

	return 0;
}